/// <reference path="../lib/phaser.comments.d.ts"/>

window.onload = function() {
    var game = new ????????();
}

class ??????? extends Phaser.Game {
    constructor() {
        //super(640,960,Phaser.AUTO,"");
        //this.state.add("Boot", new BootState());
        //this.state.start("Boot");
    }
}
